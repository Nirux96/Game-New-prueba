# PixiJS-NodeJS-Game
Browser 2D shooting game. Frag scrubs using weapons, use lava to get to them faster. Use wasd+LMB. Avoid water and sand cause it slows you down. Don't let Rick Roll you. Setup:
```bash
cd game
npm install
node server.js
```
Go to [http://localhost:54070/](http://localhost:54070/)
![Screenshot](screenshot.png?raw=true "Title")
